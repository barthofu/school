package org.example.adapters;

public class CLI {
}
