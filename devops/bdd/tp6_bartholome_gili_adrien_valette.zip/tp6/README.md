# TP 6

## Architecture

### Couches
- Classe `Database`: gestion de la base de données (database layer)
- Classe `Core`: logique métier et couche de persistence (business + persistence layer)
- Classe `CLI`: gestion du CLI (presentation layer)

### Autres
- Classe `Spell`: modèle de données